#include "list.h"
#include "node.h"
#include<iostream>
using namespace std;

int main() {
    List list;
    list.append(2);
    list.append(3);
    std::cout << list.first()->value << std::endl;
    list.insert(list.first(), 1);

    for (Node* n = list.first(); n != 0; n = list.next(n))
        std::cout << n->value << std::endl;
    list.erase(list.first());
    std::cout << list.first()->value << std::endl;
    std::cout << list.max() << std::endl;
    list.append(8);
    std::cout << list.max() << std::endl;

    printList(list);
}

