//
// Created by Niklas Wünstel on 12.12.21.
//

#include "Prime.h"

