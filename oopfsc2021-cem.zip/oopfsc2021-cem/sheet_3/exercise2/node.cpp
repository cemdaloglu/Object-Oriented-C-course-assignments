#include "Node.h"
#include <iostream>

Node::Node() {
    next = NULL;
}

Node::~Node() {}

