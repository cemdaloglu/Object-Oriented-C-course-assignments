#include "q_2.hh"

int main(){
    Rational f_1(-3,12), f_2(4,3), f_3(0);

    std::cout << f_1 << f_2 << f_3;

    f_3 = f_1 + f_2;

    std::cout << f_3;

    f_3 = f_1 * f_2;

    std::cout << f_3;

    f_3 = 4 + f_2;

    std::cout << f_3;

    f_3 = f_2 + 5;

    std::cout << f_3;

    f_3 = 12 * f_1;

    std::cout << f_3;

    f_3 = f_1 * 6;

    std::cout << f_3;

    f_3 = f_1/f_2;

    std::cout << f_3;

}
