//
// Created by Niklas Wünstel on 05.11.21.
//
#include "farey.h"
int main(){
    Farey(7);
}
